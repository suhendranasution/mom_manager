<?php
defined('BASEPATH') or exit('No direct script access allowed');

$route['mom/view/(:any)'] = 'public_mom/view/$1';