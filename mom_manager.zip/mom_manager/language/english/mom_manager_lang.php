// ... (existing strings)
$lang['mom_manager_mom'] = 'Minutes of Meeting';
$lang['mom_manager_mom_lowercase'] = 'minutes of meeting';
$lang['mom_manager_edit'] = 'Edit MOM';
$lang['mom_manager_link_copied'] = 'Public link copied to clipboard!';