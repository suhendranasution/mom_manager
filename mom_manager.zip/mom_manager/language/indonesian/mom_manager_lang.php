// ... (string yang sudah ada)
$lang['mom_manager_mom'] = 'Catatan Hasil Rapat';
$lang['mom_manager_mom_lowercase'] = 'catatan hasil rapat';
$lang['mom_manager_edit'] = 'Edit MOM';
$lang['mom_manager_link_copied'] = 'Link publik berhasil disalin ke clipboard!';